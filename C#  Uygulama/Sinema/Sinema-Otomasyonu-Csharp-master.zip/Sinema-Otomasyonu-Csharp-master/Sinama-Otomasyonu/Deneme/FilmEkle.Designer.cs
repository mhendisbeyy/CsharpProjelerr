﻿namespace Deneme
{
    partial class FilmEkle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnfilmekle = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.txtresim = new System.Windows.Forms.TextBox();
            this.btnresimsec = new System.Windows.Forms.Button();
            this.rctoyuncular = new System.Windows.Forms.RichTextBox();
            this.txtyonetmen = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtfilmturu = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.rctfilmicerik = new System.Windows.Forms.RichTextBox();
            this.txtfilmadi = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnfilmekle);
            this.groupBox1.Controls.Add(this.pictureBox1);
            this.groupBox1.Controls.Add(this.txtresim);
            this.groupBox1.Controls.Add(this.btnresimsec);
            this.groupBox1.Controls.Add(this.rctoyuncular);
            this.groupBox1.Controls.Add(this.txtyonetmen);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.txtfilmturu);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.rctfilmicerik);
            this.groupBox1.Controls.Add(this.txtfilmadi);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(106, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1174, 490);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Film Düzenle";
            // 
            // btnfilmekle
            // 
            this.btnfilmekle.Location = new System.Drawing.Point(345, 402);
            this.btnfilmekle.Name = "btnfilmekle";
            this.btnfilmekle.Size = new System.Drawing.Size(370, 57);
            this.btnfilmekle.TabIndex = 34;
            this.btnfilmekle.Text = "Film Ekle";
            this.btnfilmekle.UseVisualStyleBackColor = true;
            this.btnfilmekle.Click += new System.EventHandler(this.btnfilmekle_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(990, 123);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(156, 99);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 33;
            this.pictureBox1.TabStop = false;
            // 
            // txtresim
            // 
            this.txtresim.Location = new System.Drawing.Point(608, 191);
            this.txtresim.Multiline = true;
            this.txtresim.Name = "txtresim";
            this.txtresim.Size = new System.Drawing.Size(328, 28);
            this.txtresim.TabIndex = 32;
            // 
            // btnresimsec
            // 
            this.btnresimsec.Location = new System.Drawing.Point(942, 191);
            this.btnresimsec.Name = "btnresimsec";
            this.btnresimsec.Size = new System.Drawing.Size(37, 31);
            this.btnresimsec.TabIndex = 31;
            this.btnresimsec.Text = "...";
            this.btnresimsec.UseVisualStyleBackColor = true;
            this.btnresimsec.Click += new System.EventHandler(this.btnresimsec_Click);
            // 
            // rctoyuncular
            // 
            this.rctoyuncular.Location = new System.Drawing.Point(592, 229);
            this.rctoyuncular.Name = "rctoyuncular";
            this.rctoyuncular.Size = new System.Drawing.Size(328, 125);
            this.rctoyuncular.TabIndex = 30;
            this.rctoyuncular.Text = "";
            // 
            // txtyonetmen
            // 
            this.txtyonetmen.Location = new System.Drawing.Point(608, 144);
            this.txtyonetmen.Multiline = true;
            this.txtyonetmen.Name = "txtyonetmen";
            this.txtyonetmen.Size = new System.Drawing.Size(328, 28);
            this.txtyonetmen.TabIndex = 29;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(492, 148);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(99, 24);
            this.label7.TabIndex = 28;
            this.label7.Text = "Yönetmen:";
            // 
            // txtfilmturu
            // 
            this.txtfilmturu.Location = new System.Drawing.Point(133, 191);
            this.txtfilmturu.Multiline = true;
            this.txtfilmturu.Name = "txtfilmturu";
            this.txtfilmturu.Size = new System.Drawing.Size(328, 28);
            this.txtfilmturu.TabIndex = 27;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(14, 191);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(113, 24);
            this.label6.TabIndex = 26;
            this.label6.Text = "Film Türü :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(482, 287);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(109, 24);
            this.label5.TabIndex = 25;
            this.label5.Text = "Oyuncular :";
            // 
            // rctfilmicerik
            // 
            this.rctfilmicerik.Location = new System.Drawing.Point(136, 229);
            this.rctfilmicerik.Name = "rctfilmicerik";
            this.rctfilmicerik.Size = new System.Drawing.Size(328, 125);
            this.rctfilmicerik.TabIndex = 24;
            this.rctfilmicerik.Text = "";
            // 
            // txtfilmadi
            // 
            this.txtfilmadi.Location = new System.Drawing.Point(133, 145);
            this.txtfilmadi.Multiline = true;
            this.txtfilmadi.Name = "txtfilmadi";
            this.txtfilmadi.Size = new System.Drawing.Size(328, 28);
            this.txtfilmadi.TabIndex = 23;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(468, 194);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(123, 24);
            this.label4.TabIndex = 22;
            this.label4.Text = "Film Resim :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(10, 284);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(117, 24);
            this.label3.TabIndex = 21;
            this.label3.Text = "Film İçerik :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Monotype Corsiva", 27.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(321, 49);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(392, 45);
            this.label2.TabIndex = 20;
            this.label2.Text = "Samsun 19 Sinema Sistemi";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(26, 145);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 24);
            this.label1.TabIndex = 19;
            this.label1.Text = "Film Adı :";
            // 
            // FilmEkle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1331, 526);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "FilmEkle";
            this.Text = "FilmEkle";
            this.Load += new System.EventHandler(this.FilmEkle_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox txtresim;
        private System.Windows.Forms.Button btnresimsec;
        private System.Windows.Forms.RichTextBox rctoyuncular;
        private System.Windows.Forms.TextBox txtyonetmen;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtfilmturu;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.RichTextBox rctfilmicerik;
        private System.Windows.Forms.TextBox txtfilmadi;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnfilmekle;
    }
}