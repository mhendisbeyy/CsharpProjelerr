﻿namespace Deneme
{
    partial class FilmHakkinda
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.llblduzenle = new System.Windows.Forms.LinkLabel();
            this.lblturu = new System.Windows.Forms.Label();
            this.lblozet = new System.Windows.Forms.Label();
            this.lbloyuncular = new System.Windows.Forms.Label();
            this.lblyonetmen = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblfilmadi = new System.Windows.Forms.Label();
            this.Lblid = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.cmbSeans = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.seanslarBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.deneme1DataSet4 = new Deneme.Deneme1DataSet4();
            this.seanslarBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.deneme1DataSet1 = new Deneme.Deneme1DataSet1();
            this.seanslarTableAdapter = new Deneme.Deneme1DataSet1TableAdapters.SeanslarTableAdapter();
            this.seanslarTableAdapter1 = new Deneme.Deneme1DataSet4TableAdapters.SeanslarTableAdapter();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.seanslarBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.deneme1DataSet4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.seanslarBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.deneme1DataSet1)).BeginInit();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Monotype Corsiva", 27.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(406, 33);
            this.label3.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(392, 45);
            this.label3.TabIndex = 4;
            this.label3.Text = "Samsun 19 Sinema Sistemi";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.llblduzenle);
            this.groupBox1.Controls.Add(this.lblturu);
            this.groupBox1.Controls.Add(this.lblozet);
            this.groupBox1.Controls.Add(this.lbloyuncular);
            this.groupBox1.Controls.Add(this.lblyonetmen);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.lblfilmadi);
            this.groupBox1.Location = new System.Drawing.Point(24, 309);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(404, 403);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Film Hakkında";
            // 
            // llblduzenle
            // 
            this.llblduzenle.AutoSize = true;
            this.llblduzenle.Location = new System.Drawing.Point(0, 379);
            this.llblduzenle.Name = "llblduzenle";
            this.llblduzenle.Size = new System.Drawing.Size(79, 24);
            this.llblduzenle.TabIndex = 9;
            this.llblduzenle.TabStop = true;
            this.llblduzenle.Text = "Düzenle";
            // 
            // lblturu
            // 
            this.lblturu.AutoSize = true;
            this.lblturu.Location = new System.Drawing.Point(121, 152);
            this.lblturu.Name = "lblturu";
            this.lblturu.Size = new System.Drawing.Size(45, 24);
            this.lblturu.TabIndex = 8;
            this.lblturu.Text = "-----";
            // 
            // lblozet
            // 
            this.lblozet.AutoSize = true;
            this.lblozet.Location = new System.Drawing.Point(122, 282);
            this.lblozet.Name = "lblozet";
            this.lblozet.Size = new System.Drawing.Size(45, 24);
            this.lblozet.TabIndex = 7;
            this.lblozet.Text = "-----";
            // 
            // lbloyuncular
            // 
            this.lbloyuncular.AutoSize = true;
            this.lbloyuncular.Location = new System.Drawing.Point(126, 200);
            this.lbloyuncular.Name = "lbloyuncular";
            this.lbloyuncular.Size = new System.Drawing.Size(45, 24);
            this.lbloyuncular.TabIndex = 6;
            this.lbloyuncular.Text = "-----";
            // 
            // lblyonetmen
            // 
            this.lblyonetmen.AutoSize = true;
            this.lblyonetmen.Location = new System.Drawing.Point(121, 89);
            this.lblyonetmen.Name = "lblyonetmen";
            this.lblyonetmen.Size = new System.Drawing.Size(45, 24);
            this.lblyonetmen.TabIndex = 5;
            this.lblyonetmen.Text = "-----";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(59, 282);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(57, 24);
            this.label6.TabIndex = 4;
            this.label6.Text = "Özet :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(11, 200);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(109, 24);
            this.label5.TabIndex = 3;
            this.label5.Text = "Oyuncular :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(52, 152);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(64, 24);
            this.label4.TabIndex = 2;
            this.label4.Text = "Türü :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(11, 89);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(105, 24);
            this.label2.TabIndex = 1;
            this.label2.Text = "Yönetmen :";
            // 
            // lblfilmadi
            // 
            this.lblfilmadi.AutoSize = true;
            this.lblfilmadi.Location = new System.Drawing.Point(86, 41);
            this.lblfilmadi.Name = "lblfilmadi";
            this.lblfilmadi.Size = new System.Drawing.Size(108, 24);
            this.lblfilmadi.TabIndex = 0;
            this.lblfilmadi.Text = "--------------";
            // 
            // Lblid
            // 
            this.Lblid.AutoSize = true;
            this.Lblid.Location = new System.Drawing.Point(20, 9);
            this.Lblid.Name = "Lblid";
            this.Lblid.Size = new System.Drawing.Size(108, 24);
            this.Lblid.TabIndex = 10;
            this.Lblid.Text = "--------------";
            this.Lblid.Visible = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(24, 92);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(404, 211);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 11;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.button1);
            this.groupBox2.Controls.Add(this.comboBox2);
            this.groupBox2.Controls.Add(this.cmbSeans);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Location = new System.Drawing.Point(461, 92);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(372, 211);
            this.groupBox2.TabIndex = 12;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Bilet Al";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(116, 164);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(143, 41);
            this.button1.TabIndex = 4;
            this.button1.Text = "Ara";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(99, 107);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(191, 32);
            this.comboBox2.TabIndex = 3;
            // 
            // cmbSeans
            // 
            this.cmbSeans.FormattingEnabled = true;
            this.cmbSeans.Location = new System.Drawing.Point(98, 66);
            this.cmbSeans.Name = "cmbSeans";
            this.cmbSeans.Size = new System.Drawing.Size(191, 32);
            this.cmbSeans.TabIndex = 2;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(24, 115);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(69, 24);
            this.label7.TabIndex = 1;
            this.label7.Text = "Salon :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(24, 69);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "Seans :";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.dataGridView1);
            this.groupBox3.Location = new System.Drawing.Point(461, 332);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(561, 380);
            this.groupBox3.TabIndex = 10;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "groupBox3";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(3, 26);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(555, 351);
            this.dataGridView1.TabIndex = 0;
            // 
            // seanslarBindingSource1
            // 
            this.seanslarBindingSource1.DataMember = "Seanslar";
            this.seanslarBindingSource1.DataSource = this.deneme1DataSet4;
            // 
            // deneme1DataSet4
            // 
            this.deneme1DataSet4.DataSetName = "Deneme1DataSet4";
            this.deneme1DataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // seanslarBindingSource
            // 
            this.seanslarBindingSource.DataMember = "Seanslar";
            this.seanslarBindingSource.DataSource = this.deneme1DataSet1;
            // 
            // deneme1DataSet1
            // 
            this.deneme1DataSet1.DataSetName = "Deneme1DataSet1";
            this.deneme1DataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // seanslarTableAdapter
            // 
            this.seanslarTableAdapter.ClearBeforeFill = true;
            // 
            // seanslarTableAdapter1
            // 
            this.seanslarTableAdapter1.ClearBeforeFill = true;
            // 
            // FilmHakkinda
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1362, 742);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.Lblid);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label3);
            this.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "FilmHakkinda";
            this.Text = "FilmDetay";
            this.Load += new System.EventHandler(this.FilmDetay_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.seanslarBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.deneme1DataSet4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.seanslarBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.deneme1DataSet1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lblturu;
        private System.Windows.Forms.Label lblozet;
        private System.Windows.Forms.Label lbloyuncular;
        private System.Windows.Forms.Label lblyonetmen;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblfilmadi;
        private System.Windows.Forms.LinkLabel llblduzenle;
        private System.Windows.Forms.Label Lblid;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ComboBox cmbSeans;
        private System.Windows.Forms.GroupBox groupBox3;
        private Deneme1DataSet1 deneme1DataSet1;
        private System.Windows.Forms.BindingSource seanslarBindingSource;
        private Deneme1DataSet1TableAdapters.SeanslarTableAdapter seanslarTableAdapter;
        private Deneme1DataSet4 deneme1DataSet4;
        private System.Windows.Forms.BindingSource seanslarBindingSource1;
        private Deneme1DataSet4TableAdapters.SeanslarTableAdapter seanslarTableAdapter1;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}