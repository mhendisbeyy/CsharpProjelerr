﻿namespace Deneme
{
    partial class FilmDetay
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Lblid = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.llblduzenle = new System.Windows.Forms.LinkLabel();
            this.lblturu = new System.Windows.Forms.Label();
            this.lblozet = new System.Windows.Forms.Label();
            this.lbloyuncular = new System.Windows.Forms.Label();
            this.lblyonetmen = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblfilmadi = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(54, 107);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(404, 211);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 15;
            this.pictureBox1.TabStop = false;
            // 
            // Lblid
            // 
            this.Lblid.AutoSize = true;
            this.Lblid.Location = new System.Drawing.Point(50, 24);
            this.Lblid.Name = "Lblid";
            this.Lblid.Size = new System.Drawing.Size(79, 20);
            this.Lblid.TabIndex = 14;
            this.Lblid.Text = "--------------";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Monotype Corsiva", 27.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(436, 48);
            this.label3.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(392, 45);
            this.label3.TabIndex = 13;
            this.label3.Text = "Samsun 19 Sinema Sistemi";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.llblduzenle);
            this.groupBox1.Controls.Add(this.lblturu);
            this.groupBox1.Controls.Add(this.lblozet);
            this.groupBox1.Controls.Add(this.lbloyuncular);
            this.groupBox1.Controls.Add(this.lblyonetmen);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.lblfilmadi);
            this.groupBox1.Location = new System.Drawing.Point(54, 346);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(404, 403);
            this.groupBox1.TabIndex = 17;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Film Hakkında";
            // 
            // llblduzenle
            // 
            this.llblduzenle.AutoSize = true;
            this.llblduzenle.Location = new System.Drawing.Point(0, 379);
            this.llblduzenle.Name = "llblduzenle";
            this.llblduzenle.Size = new System.Drawing.Size(68, 20);
            this.llblduzenle.TabIndex = 9;
            this.llblduzenle.TabStop = true;
            this.llblduzenle.Text = "Düzenle";
            // 
            // lblturu
            // 
            this.lblturu.AutoSize = true;
            this.lblturu.Location = new System.Drawing.Point(119, 144);
            this.lblturu.Name = "lblturu";
            this.lblturu.Size = new System.Drawing.Size(34, 20);
            this.lblturu.TabIndex = 8;
            this.lblturu.Text = "-----";
            // 
            // lblozet
            // 
            this.lblozet.AutoSize = true;
            this.lblozet.Location = new System.Drawing.Point(119, 282);
            this.lblozet.Name = "lblozet";
            this.lblozet.Size = new System.Drawing.Size(34, 20);
            this.lblozet.TabIndex = 7;
            this.lblozet.Text = "-----";
            // 
            // lbloyuncular
            // 
            this.lbloyuncular.AutoSize = true;
            this.lbloyuncular.Location = new System.Drawing.Point(119, 200);
            this.lbloyuncular.Name = "lbloyuncular";
            this.lbloyuncular.Size = new System.Drawing.Size(34, 20);
            this.lbloyuncular.TabIndex = 6;
            this.lbloyuncular.Text = "-----";
            // 
            // lblyonetmen
            // 
            this.lblyonetmen.AutoSize = true;
            this.lblyonetmen.Location = new System.Drawing.Point(119, 89);
            this.lblyonetmen.Name = "lblyonetmen";
            this.lblyonetmen.Size = new System.Drawing.Size(34, 20);
            this.lblyonetmen.TabIndex = 5;
            this.lblyonetmen.Text = "-----";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(59, 282);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(51, 20);
            this.label6.TabIndex = 4;
            this.label6.Text = "Özet :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(22, 200);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(88, 20);
            this.label5.TabIndex = 3;
            this.label5.Text = "Oyuncular :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(61, 144);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(49, 20);
            this.label4.TabIndex = 2;
            this.label4.Text = "Türü :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(19, 89);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(91, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Yönetmen :";
            // 
            // lblfilmadi
            // 
            this.lblfilmadi.AutoSize = true;
            this.lblfilmadi.Location = new System.Drawing.Point(105, 42);
            this.lblfilmadi.Name = "lblfilmadi";
            this.lblfilmadi.Size = new System.Drawing.Size(79, 20);
            this.lblfilmadi.TabIndex = 0;
            this.lblfilmadi.Text = "--------------";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.dataGridView2);
            this.groupBox4.Location = new System.Drawing.Point(489, 107);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(561, 380);
            this.groupBox4.TabIndex = 18;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Vizyon ";
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView2.Location = new System.Drawing.Point(3, 22);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(555, 355);
            this.dataGridView2.TabIndex = 0;
            this.dataGridView2.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellDoubleClick);
            // 
            // FilmDetay
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1181, 742);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.Lblid);
            this.Controls.Add(this.label3);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "FilmDetay";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label Lblid;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.LinkLabel llblduzenle;
        private System.Windows.Forms.Label lblturu;
        private System.Windows.Forms.Label lblozet;
        private System.Windows.Forms.Label lbloyuncular;
        private System.Windows.Forms.Label lblyonetmen;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblfilmadi;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.DataGridView dataGridView2;
    }
}

